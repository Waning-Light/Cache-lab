/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    if (M == 32 && N == 32) {
        /* 32×32：8×8 分块，一次读 A 的一整行到 8 个寄存器，
           避免对角线块中 A 与 B 的冲突不命中 */
        int i, j, k;
        int a0, a1, a2, a3, a4, a5, a6, a7;
        for (i = 0; i < 32; i += 8) {
            for (j = 0; j < 32; j += 8) {
                for (k = 0; k < 8; k++) {
                    a0 = A[i+k][j+0];
                    a1 = A[i+k][j+1];
                    a2 = A[i+k][j+2];
                    a3 = A[i+k][j+3];
                    a4 = A[i+k][j+4];
                    a5 = A[i+k][j+5];
                    a6 = A[i+k][j+6];
                    a7 = A[i+k][j+7];

                    B[j+0][i+k] = a0;
                    B[j+1][i+k] = a1;
                    B[j+2][i+k] = a2;
                    B[j+3][i+k] = a3;
                    B[j+4][i+k] = a4;
                    B[j+5][i+k] = a5;
                    B[j+6][i+k] = a6;
                    B[j+7][i+k] = a7;
                }
            }
        }
    } else if (M == 64 && N == 64) {
        /* 64×64：8×8 分块 + 4×4 子块。
           先把 A 上半 4×8 分别转置到 B 的左上与右上；
           再处理 A 下半 4×8，利用 B 右上暂存的数据做交换，
           避免直接 8×8 分块造成的组冲突。 */
        int i, j, k, t;
        int a0, a1, a2, a3, a4, a5, a6, a7;
        for (i = 0; i < 64; i += 8) {
            for (j = 0; j < 64; j += 8) {
                /* 处理 A 的上半 4 行（i..i+3），共 4×8 */
                for (k = 0; k < 4; k++) {
                    a0 = A[i+k][j+0];
                    a1 = A[i+k][j+1];
                    a2 = A[i+k][j+2];
                    a3 = A[i+k][j+3];
                    a4 = A[i+k][j+4];
                    a5 = A[i+k][j+5];
                    a6 = A[i+k][j+6];
                    a7 = A[i+k][j+7];

                    /* 左 4×4 正确转置到 B 的左上 */
                    B[j+0][i+k] = a0;
                    B[j+1][i+k] = a1;
                    B[j+2][i+k] = a2;
                    B[j+3][i+k] = a3;

                    /* 右 4×4 暂存到 B 的右上，稍后换到左下 */
                    B[j+0][i+k+4] = a4;
                    B[j+1][i+k+4] = a5;
                    B[j+2][i+k+4] = a6;
                    B[j+3][i+k+4] = a7;
                }

                /* 处理 A 的下半 4 行（i+4..i+7），共 4×8 */
                for (k = 0; k < 4; k++) {
                    a0 = A[i+4][j+k];
                    a1 = A[i+5][j+k];
                    a2 = A[i+6][j+k];
                    a3 = A[i+7][j+k];
                    a4 = A[i+4][j+k+4];
                    a5 = A[i+5][j+k+4];
                    a6 = A[i+6][j+k+4];
                    a7 = A[i+7][j+k+4];

                    /* 交换：B 右上暂存的数据移到 a0..a3，
                       同时把 A 下半左 4×4 写入 B 右上 */
                    t = B[j+k][i+4]; B[j+k][i+4] = a0; a0 = t;
                    t = B[j+k][i+5]; B[j+k][i+5] = a1; a1 = t;
                    t = B[j+k][i+6]; B[j+k][i+6] = a2; a2 = t;
                    t = B[j+k][i+7]; B[j+k][i+7] = a3; a3 = t;

                    /* 原先暂存在 B 右上的 A 上半右 4×4，
                       此时在 a0..a3，写入 B 左下 */
                    B[j+k+4][i]   = a0;
                    B[j+k+4][i+1] = a1;
                    B[j+k+4][i+2] = a2;
                    B[j+k+4][i+3] = a3;

                    /* A 下半右 4×4 直接写入 B 右下 */
                    B[j+k+4][i+4] = a4;
                    B[j+k+4][i+5] = a5;
                    B[j+k+4][i+6] = a6;
                    B[j+k+4][i+7] = a7;
                }
            }
        }
    } else {
        /* 61×67 等不规则尺寸：16×16 分块 + 边界检查，
           该策略足以将 miss 控制在 2000 以下 */
        int i, j, ii, jj;
        for (i = 0; i < N; i += 16) {
            for (j = 0; j < M; j += 16) {
                for (ii = i; ii < i + 16 && ii < N; ii++) {
                    for (jj = j; jj < j + 16 && jj < M; jj++) {
                        B[jj][ii] = A[ii][jj];
                    }
                }
            }
        }
    }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

